# Lab Notes Template

## Goal
-

## Steps
1.
2.
3.

## Validation
-

## Pitfalls / Next
-
