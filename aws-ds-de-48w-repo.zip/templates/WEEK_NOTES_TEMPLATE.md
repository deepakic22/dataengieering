# Week Notes Template

## What I planned
-

## What I did (link to code / notebook)
-

## Ops / Security / Cost notes
-

## Learnings & TODO
-
