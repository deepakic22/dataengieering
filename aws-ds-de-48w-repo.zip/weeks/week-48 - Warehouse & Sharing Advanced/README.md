# Week 48 — Warehouse & Sharing Advanced

**Focus:** WLM, data sharing, spectrum, benchmarks

**AWS Services:** Redshift, Spectrum, Athena, EMR/Spark, Iceberg

**Outcome:** Performance decision guide

## Daily plan (1 hour each)

- **Day 1:** Redshift WLM queues, concurrency scaling, SQA
- **Day 2:** Sort/dist key strategies; automatic table optimization
- **Day 3:** Data sharing in Redshift; cross-account patterns; RA3 specifics
- **Day 4:** Spectrum performance & pushdown to Iceberg
- **Day 5:** Benchmark: Athena vs Redshift vs EMR/Spark for a workload
- **Day 6:** Iceberg maintenance scheduling: compaction & snapshot expiry
- **Day 7:** Mini: performance report & decision guide