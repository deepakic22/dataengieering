# Week 37 — Model Ops

**Focus:** monitoring, bias, rollout

**AWS Services:** SageMaker Monitor/Clarify, CloudWatch

**Outcome:** Monitored deployment

## Daily plan (1 hour each)

- **Day 1:** Model Monitor baselines (stats/constraints)
- **Day 2:** Data drift & model quality monitors
- **Day 3:** Bias & explainability with Clarify
- **Day 4:** Alarm routing to on-call; remediation steps
- **Day 5:** A/B testing vs canary; shadow deployments
- **Day 6:** Secure endpoints; least-privilege access
- **Day 7:** Mini: monitoring setup + rollback doc