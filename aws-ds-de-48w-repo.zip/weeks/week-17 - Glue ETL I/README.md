# Week 17 — Glue ETL I

**Focus:** core Glue Spark jobs

**AWS Services:** Glue, S3, CloudWatch

**Outcome:** ETL job to Iceberg

## Daily plan (1 hour each)

- **Day 1:** Glue 4/5 runtimes; job types; DF vs DynamicFrame
- **Day 2:** Bookmarks/idempotency; incremental reads
- **Day 3:** Transforms: joins, windows, schema drift handling
- **Day 4:** Error handling & retries; CloudWatch logs
- **Day 5:** Job parameters & config; secure creds
- **Day 6:** Outputs: Parquet/Iceberg writers; partitioning
- **Day 7:** Mini: production-style Glue job to Iceberg