# Week 45 — Testing & CI/CD

**Focus:** unit/integration/contract tests; delivery patterns

**AWS Services:** chispa, Great Expectations, Glue SR, Actions/CodeBuild

**Outcome:** Automated tested deployments

## Daily plan (1 hour each)

- **Day 1:** Unit tests for PySpark (chispa), golden datasets
- **Day 2:** Data quality tests: Great Expectations vs DQDL
- **Day 3:** Contract tests with Schema Registry; consumer-driven contracts
- **Day 4:** Integration tests with ephemeral stacks (LocalStack where useful)
- **Day 5:** CI with GitHub Actions/CodeBuild; DAG lint; pre-commit hooks
- **Day 6:** Deployment strategies: canary pipelines, blue/green ETL
- **Day 7:** Mini: end-to-end CI pipeline for a sample project