# Week 39 — Capstone A

**Focus:** Lakehouse+Governance+DQ

**AWS Services:** Glue, LF, Athena, SFN/MWAA

**Outcome:** End-to-end lakehouse

## Daily plan (1 hour each)

- **Day 1:** Integrate S3→Glue→Iceberg→Athena
- **Day 2:** Apply LF governance (row/col)
- **Day 3:** Add DQDL checks & alerts
- **Day 4:** Orchestrate via SFN or MWAA
- **Day 5:** Cost/ops/security documentation
- **Day 6:** Architecture diagram & IaC skeleton
- **Day 7:** Mini: dry-run end-to-end + checklist