# Week 32 — Observability & Reliability

**Focus:** logging, metrics, DR

**AWS Services:** CloudWatch, CloudTrail, AWS Backup

**Outcome:** Ops dashboard + drill

## Daily plan (1 hour each)

- **Day 1:** CloudWatch Logs/Metrics/Alarms for Glue/EMR
- **Day 2:** Spark History Server; job dashboards
- **Day 3:** CloudTrail for data/permission changes
- **Day 4:** Backup/restore drills; S3 versioning; AWS Backup
- **Day 5:** SLOs, error budgets, incident playbooks
- **Day 6:** Lineage notes (manual/metadata)
- **Day 7:** Mini: alarmed dashboard + backup drill log