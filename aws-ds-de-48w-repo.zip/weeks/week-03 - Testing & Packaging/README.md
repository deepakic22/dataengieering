# Week 03 — Testing & Packaging

**Focus:** tests, lint, dist, perf

**AWS Services:** Local

**Outcome:** Tested package

## Daily plan (1 hour each)

- **Day 1:** pytest basics; fixtures; parametrize
- **Day 2:** Format/lint: black + ruff/pre-commit
- **Day 3:** Packaging: pyproject/wheels; editable installs
- **Day 4:** Concurrency: threads vs processes
- **Day 5:** Async I/O 101: async/await, aiohttp
- **Day 6:** Perf: profiling, memory tips
- **Day 7:** Mini-task: add tests + pre-commit + tiny benchmark