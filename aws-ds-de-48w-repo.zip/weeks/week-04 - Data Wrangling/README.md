# Week 04 — Data Wrangling

**Focus:** Pandas/Polars/NumPy + SQL bridge

**AWS Services:** Local

**Outcome:** Local ETL

## Daily plan (1 hour each)

- **Day 1:** Pandas read/clean/merge; dtypes
- **Day 2:** GroupBy, window-like ops; Parquet
- **Day 3:** Polars (optional) lazy frames vs pandas
- **Day 4:** NumPy vectors; date/time
- **Day 5:** SQLite schema + JOINs (sqlite3)
- **Day 6:** Export to S3-friendly Parquet partitions
- **Day 7:** Mini: CSV→clean→Parquet + README