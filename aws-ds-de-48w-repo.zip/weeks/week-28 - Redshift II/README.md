# Week 28 — Redshift II

**Focus:** Spectrum, ELT, MVs

**AWS Services:** Redshift + Spectrum + Athena

**Outcome:** ELT + MV + cost notes

## Daily plan (1 hour each)

- **Day 1:** External schema to Iceberg via Spectrum
- **Day 2:** MERGE upserts; late-arrival strategy
- **Day 3:** Materialized views; refresh policies
- **Day 4:** Compare cost/latency vs Athena
- **Day 5:** UNLOAD to Parquet; data sharing
- **Day 6:** Access control with LF integration
- **Day 7:** Mini: ELT pipeline + MV + comparison doc