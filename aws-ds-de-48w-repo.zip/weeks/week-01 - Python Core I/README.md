# Week 01 — Python Core I

**Focus:** syntax, flow control

**AWS Services:** Local

**Outcome:** CLI + notes

## Daily plan (1 hour each)

- **Day 1:** Setup (pyenv/venv), pip, REPL, script vs module
- **Day 2:** Types/ops, slicing, f-strings, immutability
- **Day 3:** Control flow (if/loops), truthiness
- **Day 4:** Functions, args/kwargs, docstrings
- **Day 5:** Exceptions (try/except), custom errors
- **Day 6:** Files & paths (pathlib), JSON/YAML
- **Day 7:** Mini-task: CLI reads CSV and prints stats