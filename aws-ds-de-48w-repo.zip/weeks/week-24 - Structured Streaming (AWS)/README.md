# Week 24 — Structured Streaming (AWS)

**Focus:** Spark streaming end-to-end

**AWS Services:** Glue/EMR Spark, S3, Athena

**Outcome:** Streaming → Iceberg pipeline

## Daily plan (1 hour each)

- **Day 1:** Source: Kinesis/MSK; auth & endpoints
- **Day 2:** Watermarks & stateful ops; exactly-once sinks
- **Day 3:** Checkpointing on S3; recovery testing
- **Day 4:** Sink to Iceberg with upsert semantics
- **Day 5:** Athena verification over streaming outputs
- **Day 6:** Monitoring jobs; CloudWatch metrics/Spark UI
- **Day 7:** Mini: streaming job → Iceberg → Athena