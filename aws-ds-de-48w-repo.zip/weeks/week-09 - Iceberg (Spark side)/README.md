# Week 09 — Iceberg (Spark side)

**Focus:** layout, evolution, merge

**AWS Services:** Local Spark

**Outcome:** Iceberg demo

## Daily plan (1 hour each)

- **Day 1:** Parquet internals; predicate pushdown
- **Day 2:** Iceberg 101: snapshots/manifests
- **Day 3:** Write modes: append/overwrite/replace; time travel
- **Day 4:** Schema & partition evolution
- **Day 5:** MERGE INTO with Iceberg; dedupe
- **Day 6:** Maintenance: compaction & retention
- **Day 7:** Mini: Spark→Iceberg + time-travel demo