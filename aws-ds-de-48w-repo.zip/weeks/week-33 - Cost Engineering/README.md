# Week 33 — Cost Engineering

**Focus:** optimize storage/scan/compute

**AWS Services:** S3, Athena, Kinesis/MSK, Glue/EMR, Redshift

**Outcome:** Cost playbook

## Daily plan (1 hour each)

- **Day 1:** S3 lifecycle/Glacier tiers; replication cost
- **Day 2:** Small-file/compaction strategies; parquet sizing
- **Day 3:** Athena: partitioning & projections; bytes reduction
- **Day 4:** Kinesis/MSK: shard/broker tuning & retention
- **Day 5:** Glue/EMR DPUs & instance families; spot savings
- **Day 6:** Redshift sizing; concurrency scaling; Advisor
- **Day 7:** Mini: cost playbook with 3 concrete savings