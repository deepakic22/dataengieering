# Week 02 — Python Core II

**Focus:** collections, OOP, typing

**AWS Services:** Local

**Outcome:** Refactored CLI

## Daily plan (1 hour each)

- **Day 1:** Lists/tuples/sets/dicts; comprehensions
- **Day 2:** Iterables/iterators/generators; itertools
- **Day 3:** OOP: classes/methods/inheritance
- **Day 4:** dataclass + typing; type hints
- **Day 5:** Imports/packages; project layout
- **Day 6:** Logging config & structured logs
- **Day 7:** Mini-task: refactor CLI with logging + types