# Week 35 — SageMaker I

**Focus:** Processing/Training/Studio

**AWS Services:** SageMaker Studio/Jobs

**Outcome:** Baseline on SM jobs

## Daily plan (1 hour each)

- **Day 1:** SageMaker Studio setup; projects & roles
- **Day 2:** Processing jobs (feature gen, eval)
- **Day 3:** Training jobs (builtin or script mode)
- **Day 4:** Artifacts to S3; metrics to CW; lineage
- **Day 5:** Hyperparams & distrib training basics
- **Day 6:** Batch Transform vs endpoints (when which)
- **Day 7:** Mini: move baseline to Processing/Training