# Week 30 — Contracts & DQ at Scale

**Focus:** schema + DQ governance

**AWS Services:** Glue SR, DataZone

**Outcome:** Contracted pipeline + alerts

## Daily plan (1 hour each)

- **Day 1:** Contract formats: Avro/JSON/Protobuf
- **Day 2:** Glue Schema Registry rules; compatibility
- **Day 3:** Producer/consumer responsibility model
- **Day 4:** DQ gates across pipelines; SLAs & routing
- **Day 5:** Alerting paths (ChatOps/Email) & runbooks
- **Day 6:** Catalog surfacing contracts (DataZone)
- **Day 7:** Mini: registry-backed contract + DQ policy