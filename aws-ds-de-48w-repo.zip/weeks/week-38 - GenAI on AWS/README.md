# Week 38 — GenAI on AWS

**Focus:** RAG, vectors, guardrails

**AWS Services:** Bedrock, OpenSearch/Aurora pgvector

**Outcome:** RAG POC

## Daily plan (1 hour each)

- **Day 1:** Embeddings & chunking strategies
- **Day 2:** Vector DB: OpenSearch vector vs Aurora pgvector
- **Day 3:** Bedrock models & invocation basics
- **Day 4:** Knowledge Bases & data sync; metadata
- **Day 5:** Guardrails (policies, filters)
- **Day 6:** Eval & telemetry (quality & safety)
- **Day 7:** Mini: small RAG POC with guardrails