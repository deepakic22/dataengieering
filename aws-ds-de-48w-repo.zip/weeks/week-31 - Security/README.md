# Week 31 — Security

**Focus:** IAM, KMS, VPC, LF

**AWS Services:** IAM, KMS, LF, VPC Endpoints

**Outcome:** Security blueprint

## Daily plan (1 hour each)

- **Day 1:** IAM least-privilege & permission boundaries
- **Day 2:** KMS envelope encryption; CMK policies
- **Day 3:** Private subnets & VPC endpoints; egress control
- **Day 4:** LF fine-grained access; column masking
- **Day 5:** Cross-account data sharing patterns
- **Day 6:** Tokenization & PII strategies
- **Day 7:** Mini: secure blueprint with policy snippets