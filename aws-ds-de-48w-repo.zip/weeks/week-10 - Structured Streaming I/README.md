# Week 10 — Structured Streaming I

**Focus:** concepts to code

**AWS Services:** Local Spark

**Outcome:** Streaming demo

## Daily plan (1 hour each)

- **Day 1:** Streaming model: micro-batch vs continuous
- **Day 2:** Event-time vs processing-time
- **Day 3:** Watermarks & stateful ops; late data
- **Day 4:** Sources/sinks (files/Kinesis/Kafka/S3/Iceberg)
- **Day 5:** Checkpointing; exactly-once sinks
- **Day 6:** Backpressure; monitoring
- **Day 7:** Mini: local file stream → agg → S3 sink