# Week 20 — Orchestration (Airflow)

**Focus:** DAGs, backfills, SLAs

**AWS Services:** MWAA

**Outcome:** Working Airflow DAG

## Daily plan (1 hour each)

- **Day 1:** DAG basics; operators; sensors; XCom
- **Day 2:** Backfills & catchup; schedule_interval; SLAs
- **Day 3:** Connections & variables; secrets
- **Day 4:** Alerting & retries; task-level failure patterns
- **Day 5:** Port SFN pipeline to Airflow DAG
- **Day 6:** Compare SFN vs MWAA trade-offs
- **Day 7:** Mini: run DAG on MWAA with backfill