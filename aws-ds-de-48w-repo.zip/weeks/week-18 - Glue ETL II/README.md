# Week 18 — Glue ETL II

**Focus:** DQ + error/alert patterns

**AWS Services:** Glue DQDL, CloudWatch

**Outcome:** DQ-gated ETL

## Daily plan (1 hour each)

- **Day 1:** Glue Data Quality (DQDL) rule types
- **Day 2:** Authoring DQ rules; thresholds; null/distinct/range
- **Day 3:** Integrate DQ with jobs; fail gates
- **Day 4:** Anomaly checks & drift detection
- **Day 5:** Alerting via CloudWatch Alarms/EventBridge
- **Day 6:** Job observability: metrics, logs, tracing notes
- **Day 7:** Mini: DQDL-enforced job with alarms