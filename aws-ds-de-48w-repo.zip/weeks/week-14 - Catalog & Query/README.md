# Week 14 — Catalog & Query

**Focus:** Glue Catalog + Athena

**AWS Services:** Glue, Athena

**Outcome:** Queryable lake skeleton

## Daily plan (1 hour each)

- **Day 1:** Glue DB & table design; crawlers vs direct DDL
- **Day 2:** Athena CTAS/INSERT-SELECT; workgroups
- **Day 3:** Partitions & partition projection
- **Day 4:** Compression & column stats; optimize scans
- **Day 5:** Athena federated query (concepts)
- **Day 6:** Permissions: IAM & Lake Formation interplay
- **Day 7:** Mini: create tables + 5 cost-efficient queries