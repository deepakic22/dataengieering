# Week 15 — Iceberg on Athena

**Focus:** table ops & maintenance

**AWS Services:** Athena (Iceberg)

**Outcome:** Iceberg ops via SQL

## Daily plan (1 hour each)

- **Day 1:** Create Iceberg table in Athena; table props
- **Day 2:** Schema evolution; ADD/DROP/RENAME columns
- **Day 3:** Snapshot/time-travel queries
- **Day 4:** Compaction & housekeeping (rewrite data/files)
- **Day 5:** MERGE INTO from staged data
- **Day 6:** Partition evolution & hidden partitioning
- **Day 7:** Mini: migrate Parquet table → Iceberg; test merge