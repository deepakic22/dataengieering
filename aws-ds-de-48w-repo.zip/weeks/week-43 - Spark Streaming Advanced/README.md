# Week 43 — Spark Streaming Advanced

**Focus:** joins, state, exactly-once, late data, testing

**AWS Services:** Glue/EMR Spark, Iceberg, S3, CloudWatch

**Outcome:** Production-grade streaming job

## Daily plan (1 hour each)

- **Day 1:** Stream-stream & stream-static joins with watermarks
- **Day 2:** State store scaling & cleanup; RocksDB state store patterns
- **Day 3:** Exactly-once semantics: idempotent/transactional Iceberg writes
- **Day 4:** Late/out-of-order events: watermark tuning strategies
- **Day 5:** Backpressure & autoscaling with EMR/Glue; checkpoint hygiene
- **Day 6:** Testing streaming queries; reliability patterns
- **Day 7:** Mini: resilient streaming job with join + late data handling