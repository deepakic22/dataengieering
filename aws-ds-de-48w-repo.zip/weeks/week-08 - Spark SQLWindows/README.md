# Week 08 — Spark SQL/Windows

**Focus:** joins, windows, SQL, UDFs

**AWS Services:** Local Spark

**Outcome:** Analytical job

## Daily plan (1 hour each)

- **Day 1:** Joins + join hints (all types)
- **Day 2:** Window functions (lag/lead/row_number)
- **Day 3:** Aggregations; grouping sets; skewed keys
- **Day 4:** Spark SQL; temp views; DF vs SQL tradeoffs
- **Day 5:** UDF vs built-ins vs pandas UDFs
- **Day 6:** Partitioning/bucketing; file sizing; small-files
- **Day 7:** Mini: joins+windows analytical job