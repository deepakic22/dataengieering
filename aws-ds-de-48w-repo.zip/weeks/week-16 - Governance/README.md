# Week 16 — Governance

**Focus:** Lake Formation + AWS DataZone

**AWS Services:** LF, DataZone, Athena, Glue

**Outcome:** Fine-grained governed datasets

## Daily plan (1 hour each)

- **Day 1:** LF permissions model; principals, LF tags
- **Day 2:** Row/column-level security; cell masking patterns
- **Day 3:** Cross-account shares; external data filtering
- **Day 4:** LF with Athena/Glue/Spark integration
- **Day 5:** AWS DataZone: domains/projects/catalog/approvals
- **Day 6:** Data subscriptions & entitlements (DataZone)
- **Day 7:** Mini: tag-based policy + DataZone catalog entry