# Week 13 — S3 Data Lake Fundamentals

**Focus:** layout, partitions, lifecycle

**AWS Services:** S3

**Outcome:** Well-structured bucket

## Daily plan (1 hour each)

- **Day 1:** S3 layout: bronze/silver/gold; naming standards
- **Day 2:** Partition key strategy; hive-style paths
- **Day 3:** Lifecycle basics: IA/Glacier; retention
- **Day 4:** Versioning & replication (CRR/SRR) overview
- **Day 5:** S3 consistency & multipart uploads; checksum
- **Day 6:** Access patterns: prefix design; list/get costs
- **Day 7:** Mini: create bucket + folder plan + lifecycle rule