# Week 40 — Capstone B

**Focus:** Streaming + ML pipeline

**AWS Services:** Kinesis/MSK, Spark, Iceberg, SageMaker

**Outcome:** Final demo & repo

## Daily plan (1 hour each)

- **Day 1:** Stream ingest (Kinesis/MSK) → Spark streaming
- **Day 2:** Sink to Iceberg; Athena incremental views
- **Day 3:** SageMaker pipeline to retrain/promote
- **Day 4:** Monitoring (Model Monitor) + alarms
- **Day 5:** Security & cost final review
- **Day 6:** Demo script & README polish
- **Day 7:** Mini: final demo run + repo publish