# Week 41 — Airflow Advanced (MWAA)

**Focus:** TaskFlow, deferrables, secrets, testing, observability

**AWS Services:** MWAA, Secrets Manager, CloudWatch, CodeBuild/Actions

**Outcome:** Advanced, tested DAGs with CI/CD

## Daily plan (1 hour each)

- **Day 1:** TaskFlow API & dynamic task mapping
- **Day 2:** Deferrable operators & Datasets-based scheduling
- **Day 3:** Secrets backends (Secrets Manager/SSM) & connections as code
- **Day 4:** Packaging DAGs on MWAA: providers, plugins, constraints
- **Day 5:** DAG testing (pytest-airflow), CI/CD (CodeBuild/GitHub Actions), DAG validation
- **Day 6:** Observability: Airflow metrics, SLA miss callbacks, audit logs
- **Day 7:** Mini: complex DAG with dataset triggers + unit tests