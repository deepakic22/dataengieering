# Week 36 — SageMaker II

**Focus:** Pipelines/FS/Registry/Deploy

**AWS Services:** SageMaker Pipelines/FS/Registry

**Outcome:** End-to-end pipeline

## Daily plan (1 hour each)

- **Day 1:** SageMaker Pipelines DAG; parameters
- **Day 2:** Feature Store: offline/online groups
- **Day 3:** Register/promote model; Model Registry
- **Day 4:** Deploy: real-time vs batch; autoscaling
- **Day 5:** Blue/green or canary deploy patterns
- **Day 6:** Failure/rollback strategies
- **Day 7:** Mini: full SM pipeline + feature store + deploy