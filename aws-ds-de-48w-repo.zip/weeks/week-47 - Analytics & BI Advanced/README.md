# Week 47 — Analytics & BI Advanced

**Focus:** QS performance, RLS/CLS, embedding, ML insights

**AWS Services:** QuickSight, LF, Athena/Redshift

**Outcome:** Advanced QuickSight dashboard

## Daily plan (1 hour each)

- **Day 1:** SPICE sizing/perf; dataset modeling best practices
- **Day 2:** Parameters, controls, actions; multi-dataset joins
- **Day 3:** Advanced RLS/CLS with LF tags integration
- **Day 4:** Embedding dashboards; programmatic asset mgmt
- **Day 5:** Forecasting & ML Insights; anomaly detection
- **Day 6:** Cost control & refresh strategies for QuickSight
- **Day 7:** Mini: advanced dashboard with RLS/CLS and params