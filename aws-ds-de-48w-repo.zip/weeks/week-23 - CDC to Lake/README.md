# Week 23 — CDC to Lake

**Focus:** Debezium/DMS to S3/Iceberg

**AWS Services:** MSK Connect/DMS, S3, Glue SR

**Outcome:** CDC landed dataset

## Daily plan (1 hour each)

- **Day 1:** CDC concepts: log-based, snapshot, ordering
- **Day 2:** MSK Connect (Debezium) setup & connectors
- **Day 3:** Alternative: AWS DMS endpoints & tasks
- **Day 4:** Schema evolution with CDC; schema registry
- **Day 5:** Dedupe & late-arrival handling design
- **Day 6:** Land CDC to S3; partition by table/op/date
- **Day 7:** Mini: CDC → S3 → Iceberg ready dataset