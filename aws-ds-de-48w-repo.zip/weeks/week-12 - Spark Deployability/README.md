# Week 12 — Spark Deployability

**Focus:** tests, packaging, submit

**AWS Services:** Local Spark

**Outcome:** Local capstone

## Daily plan (1 hour each)

- **Day 1:** Testing Spark (pytest/chispa); golden-data
- **Day 2:** Packaging deps (zip/wheel; --py-files)
- **Day 3:** Config/secrets; S3 path conventions
- **Day 4:** spark-submit; params; retries
- **Day 5:** Observability hooks; custom metrics
- **Day 6:** Local capstone: batch + streaming to Iceberg
- **Day 7:** Mini: final polish & README