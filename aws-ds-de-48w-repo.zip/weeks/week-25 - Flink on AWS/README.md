# Week 25 — Flink on AWS

**Focus:** windows, state, checkpoints

**AWS Services:** Managed Service for Apache Flink

**Outcome:** Flink job to S3

## Daily plan (1 hour each)

- **Day 1:** Why Flink: event-time first, state mgmt
- **Day 2:** Windows (tumbling/sliding/session); watermarks
- **Day 3:** State backends; checkpoint/savepoint
- **Day 4:** Exactly-once sinks; connectors overview
- **Day 5:** Managed Service for Apache Flink setup
- **Day 6:** Basic job: keyed window agg to S3
- **Day 7:** Mini: Flink job + savepoint test