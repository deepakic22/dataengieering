# Week 06 — Python↔SQL/AWS Bridge

**Focus:** db access, boto3, athena client

**AWS Services:** Local

**Outcome:** Containerized ETL

## Daily plan (1 hour each)

- **Day 1:** SQLAlchemy basics
- **Day 2:** PyAthena basics (query S3 via Athena)
- **Day 3:** Boto3 S3 list/get/put; pagination
- **Day 4:** Structured logs → CloudWatch (plan)
- **Day 5:** Package job for deploy; per-env config
- **Day 6:** Repo tidy & recap
- **Day 7:** Mini: container-ready local ETL