# Week 42 — Kafka/MSK Advanced & Connect

**Focus:** replication, producer/consumer tuning, Connect, schema, security

**AWS Services:** Amazon MSK, MSK Connect, Glue Schema Registry, S3

**Outcome:** Robust MSK pipeline with CDC & schemas

## Daily plan (1 hour each)

- **Day 1:** KRaft controller quorum, replication, min ISR, rack-aware
- **Day 2:** Producer configs: acks/linger/batch.size/compression trade-offs
- **Day 3:** Consumer lag monitoring; rebalance (eager/cooperative), static membership
- **Day 4:** MSK Connect: Debezium source, S3/Iceberg sink, DLQs & error handling
- **Day 5:** Schema Registry: Glue vs Confluent; compatibility modes
- **Day 6:** Security: IAM auth, TLS, private connectivity patterns
- **Day 7:** Mini: Debezium CDC → MSK → S3/Iceberg with schema evolution test