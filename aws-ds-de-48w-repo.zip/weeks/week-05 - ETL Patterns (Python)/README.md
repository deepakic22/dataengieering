# Week 05 — ETL Patterns (Python)

**Focus:** robust local ETL

**AWS Services:** Local

**Outcome:** Contracted ETL

## Daily plan (1 hour each)

- **Day 1:** Config mgmt; env vars/.env
- **Day 2:** Idempotency, retries/backoff, checkpoints
- **Day 3:** Formats: CSV/JSON/Parquet/ORC trade-offs
- **Day 4:** Job layout: main(), modular transforms
- **Day 5:** Data contracts: JSON/Avro + pydantic
- **Day 6:** CLI ergonomics (argparse/typer)
- **Day 7:** Mini: robust local ETL w/ schema validation