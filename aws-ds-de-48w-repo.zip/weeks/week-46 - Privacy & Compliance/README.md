# Week 46 — Privacy & Compliance

**Focus:** PII discovery, masking, retention, audit, clean rooms

**AWS Services:** Macie, Lake Formation, S3 Object Lock, CloudTrail

**Outcome:** Compliant PII handling workflow

## Daily plan (1 hour each)

- **Day 1:** DPDP (India) & GDPR basics; data subject requests
- **Day 2:** PII discovery with Amazon Macie; classification & tagging
- **Day 3:** Masking/tokenization; LF column-level security
- **Day 4:** Retention policies with S3 lifecycle; Object Lock/WORM; legal holds
- **Day 5:** Audit trails: CloudTrail + Athena queries; access reviews
- **Day 6:** Secure sharing & clean rooms (AWS Clean Rooms) basics
- **Day 7:** Mini: PII pipeline with discovery + masking + audit