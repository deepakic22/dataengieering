# Week 11 — Spark Tuning

**Focus:** internals & tuning

**AWS Services:** Local Spark

**Outcome:** Tuned job

## Daily plan (1 hour each)

- **Day 1:** Catalyst/Tungsten; WSCG basics
- **Day 2:** AQE: coalesce partitions; skew join
- **Day 3:** Broadcast joins; spill; sort-merge vs shuffle-hash
- **Day 4:** Executor/driver memory; GC; failures
- **Day 5:** Repartition/coalesce strategy; file sizing for S3
- **Day 6:** Metrics/logs; Spark UI analysis
- **Day 7:** Mini: tune a job; before/after notes