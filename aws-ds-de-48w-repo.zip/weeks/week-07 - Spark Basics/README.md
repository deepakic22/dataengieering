# Week 07 — Spark Basics

**Focus:** mental model + DataFrames

**AWS Services:** Local Spark

**Outcome:** Local Spark job

## Daily plan (1 hour each)

- **Day 1:** Spark architecture; lazy eval; Driver/Executors
- **Day 2:** SparkSession; read CSV/JSON/Parquet; schemas
- **Day 3:** Transformations vs actions; explain(); deps
- **Day 4:** DataFrame ops; null handling
- **Day 5:** Caching & persistence; when to cache
- **Day 6:** Project structure; logging in Spark
- **Day 7:** Mini: local Spark CSV→Parquet + docs