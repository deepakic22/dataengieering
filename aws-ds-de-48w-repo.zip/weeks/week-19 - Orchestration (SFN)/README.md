# Week 19 — Orchestration (SFN)

**Focus:** state machines & retries

**AWS Services:** Step Functions, EventBridge

**Outcome:** End-to-end pipeline

## Daily plan (1 hour each)

- **Day 1:** ASL basics; states: Task/Choice/Parallel/Map
- **Day 2:** Retry, Catch, DLQ patterns
- **Day 3:** EventBridge schedules & triggers
- **Day 4:** Chaining: crawler→ETL→DQ→Athena check
- **Day 5:** Input/Output/ResultPath shaping
- **Day 6:** Execution history & troubleshooting
- **Day 7:** Mini: deploy a SFN pipeline around your Glue job