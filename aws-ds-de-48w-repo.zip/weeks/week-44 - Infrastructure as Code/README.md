# Week 44 — Infrastructure as Code

**Focus:** model platform in code, LF perms, CI/CD for IaC

**AWS Services:** CDK/Terraform, CloudFormation, CodePipeline

**Outcome:** Deployed dev lakehouse stack

## Daily plan (1 hour each)

- **Day 1:** Terraform vs CDK vs CloudFormation: choose & scaffold modules
- **Day 2:** Model S3/Glue/Athena/Iceberg resources as code
- **Day 3:** Lake Formation permissions via IaC (LF-TBAC)
- **Day 4:** Provision MSK/Kinesis/Redshift/SageMaker via IaC
- **Day 5:** MWAA & Step Functions as code; packaging & deps
- **Day 6:** CI/CD for IaC: pipelines, drift detection, policy checks
- **Day 7:** Mini: provision a dev lakehouse stack with IaC