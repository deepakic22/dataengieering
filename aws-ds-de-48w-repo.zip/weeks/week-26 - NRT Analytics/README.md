# Week 26 — NRT Analytics

**Focus:** Athena + QuickSight over streams

**AWS Services:** Athena, QuickSight, LF

**Outcome:** KPI dashboard with RLS

## Daily plan (1 hour each)

- **Day 1:** Incremental views & freshness SLAs
- **Day 2:** Athena over streaming outputs; CTAS patterns
- **Day 3:** QuickSight dataset & SPICE refresh
- **Day 4:** Row-level security via LF/Tags
- **Day 5:** Dashboards & alerts for stale data
- **Day 6:** Perf & cost hygiene
- **Day 7:** Mini: near-real-time KPI dashboard