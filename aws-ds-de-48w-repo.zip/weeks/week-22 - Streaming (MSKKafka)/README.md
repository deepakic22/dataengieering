# Week 22 — Streaming (MSK/Kafka)

**Focus:** brokers, groups, EOS

**AWS Services:** Amazon MSK, Glue SR

**Outcome:** Kafka sample with schemas

## Daily plan (1 hour each)

- **Day 1:** Cluster & broker basics; partitions; ISR
- **Day 2:** Consumer groups; rebalancing; offsets
- **Day 3:** Transactions/EOS patterns
- **Day 4:** Auth & networking; private access
- **Day 5:** Glue Schema Registry; Avro/JSON schemas
- **Day 6:** Cost & sizing brokers; storage/retention
- **Day 7:** Mini: MSK produce/consume + schema validation