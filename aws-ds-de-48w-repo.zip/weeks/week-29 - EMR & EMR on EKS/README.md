# Week 29 — EMR & EMR on EKS

**Focus:** runtime choices & tuning

**AWS Services:** EMR / EMR on EKS

**Outcome:** EMR comparison report

## Daily plan (1 hour each)

- **Day 1:** When EMR vs Glue; custom runtimes & libs
- **Day 2:** EMR 7.x setup; autoscaling; spot
- **Day 3:** Debugging Spark on EMR; logs; metrics
- **Day 4:** EMR on EKS basics; isolation; scaling
- **Day 5:** Port a Glue Spark job to EMR; compare cost
- **Day 6:** Data locality & file sizing effects
- **Day 7:** Mini: EMR job report (perf/cost)