# Week 27 — Redshift I

**Focus:** load, keys, WLM

**AWS Services:** Redshift Serverless

**Outcome:** Star-schema warehouse

## Daily plan (1 hour each)

- **Day 1:** Create workgroup; namespaces; security
- **Day 2:** Load COPY from S3; UNLOAD patterns
- **Day 3:** Dist & sort keys; compression encodings
- **Day 4:** WLM basics; concurrency scaling
- **Day 5:** Staging → star schema (facts/dims)
- **Day 6:** Basic perf tuning; analyze/vacuum notes
- **Day 7:** Mini: star schema with sample data