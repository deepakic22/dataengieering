# Week 21 — Streaming (Kinesis)

**Focus:** throughput & consumers

**AWS Services:** Kinesis Data Streams

**Outcome:** Sample stream with monitors

## Daily plan (1 hour each)

- **Day 1:** Shard math: capacity, scaling, retention
- **Day 2:** Producers (KPL/Kinesis Agent) & batching
- **Day 3:** Consumers (KCL/SDK), enhanced fan-out
- **Day 4:** Checkpoints & failure handling
- **Day 5:** Monitoring & alarms; cost levers
- **Day 6:** Designing partitions/keys for fairness
- **Day 7:** Mini: producer+consumer sample with alarms