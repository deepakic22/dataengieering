# Week 34 — ML Basics (Python)

**Focus:** EDA, training, metrics

**AWS Services:** Local Python

**Outcome:** Baseline model + CLI

## Daily plan (1 hour each)

- **Day 1:** EDA & feature engineering (pandas)
- **Day 2:** Train/test split; cross-validation
- **Day 3:** Metrics: ROC/AUC, F1, regression metrics
- **Day 4:** Model persistence (joblib/pickle); versioning
- **Day 5:** Batch inference script; CLI flags
- **Day 6:** Repro seeds; small unit tests for features
- **Day 7:** Mini: baseline model + inference CLI